package com.example.myrecyclerview

class GridPojo(val name: String, val image: Int) {
}